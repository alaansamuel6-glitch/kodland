from random import randint
import requests

class Pokemon:
    pokemons = {}
    
    def __init__(self, pokemon_trainer):
        self.pokemon_trainer = pokemon_trainer   
        self.pokemon_number = randint(1, 1000)
        self.get_img()
        self.get_name()
        self.get_height()
        self.get_weight()
        self.get_types()
        self.get_stats()
        Pokemon.pokemons[pokemon_trainer] = self

    def get_img(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.img = data['sprites']['other']['official-artwork']['front_default']
        else:
            self.img = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png"
    
    def get_name(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.name = data['forms'][0]['name']
        else:
            self.name = "Pikachu"
    
    def get_height(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.height = data['height']
        else:
            self.height = 6
    
    def get_weight(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.weight = data['weight']
        else:
            self.weight = 60
    
    def get_types(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.types = [type_info['type']['name'] for type_info in data['types']]
        else:
            self.types = ["electric"]
    
    def get_stats(self):
        url = f'https://pokeapi.co/api/v2/pokemon/{self.pokemon_number}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            self.hp = data['stats'][0]['base_stat']
            self.attack = data['stats'][1]['base_stat']
            self.defense = data['stats'][2]['base_stat']
            self.speed = data['stats'][5]['base_stat']
        else:
            self.hp = 35
            self.attack = 55
            self.defense = 40
            self.speed = 90

    def info(self):
        return f"Имя: {self.name}, Тип: {self.types[0]}, HP: {self.hp}, Атака: {self.attack}"

    def show_img(self):
        return self.img
    
    def set_name(self, new_name):
        self.name = new_name
    
    def train(self):
        self.attack += 5
        self.hp += 3