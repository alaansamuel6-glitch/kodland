import telebot 
from config import token
from logic import Pokemon

bot = telebot.TeleBot(token) 

@bot.message_handler(commands=['go'])
def go(message):
    username = message.from_user.username
    if username in Pokemon.pokemons:
        del Pokemon.pokemons[username]
    
    pokemon = Pokemon(username)
    bot.send_message(message.chat.id, pokemon.info())
    bot.send_photo(message.chat.id, pokemon.show_img())

@bot.message_handler(commands=['train'])
def train(message):
    username = message.from_user.username
    if username in Pokemon.pokemons.keys():
        pokemon = Pokemon.pokemons[username]
        pokemon.train()
        bot.send_message(message.chat.id, f"Покемон потренировался!\n{pokemon.info()}")
    else:
        bot.reply_to(message, "Сначала создай покемона командой /go")

@bot.message_handler(commands=['rename'])
def rename(message):
    username = message.from_user.username
    if username in Pokemon.pokemons.keys():
        try:
            new_name = message.text.split(' ', 1)[1]
            pokemon = Pokemon.pokemons[username]
            pokemon.set_name(new_name)
            # Отправляем новое имя и старую картинку
            bot.send_message(message.chat.id, f"Имя изменено на {new_name}")
            bot.send_message(message.chat.id, pokemon.info())
            bot.send_photo(message.chat.id, pokemon.show_img())  # Картинка та же
        except:
            bot.reply_to(message, "Используй: /rename <новое_имя>")
    else:
        bot.reply_to(message, "Сначала создай покемона командой /go")

bot.infinity_polling(none_stop=True)